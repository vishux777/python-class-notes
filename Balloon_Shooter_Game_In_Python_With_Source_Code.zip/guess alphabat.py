import random

# List of words to choose from
words = ["apple", "banana", "orange", "grape", "melon"]

# Select a random word from the list
secret_word = random.choice(words)

# Initialize the guessed letters
guessed_letters = []

# Set the maximum number of incorrect guesses allowed
max_attempts = 6

# Function to display the hangman figure
def display_hangman(incorrect_guesses):
    stages = [
        """
           --------
           |      |
           |      O
           |     \\|/
           |      |
           |     / \\
        """,
        """
           --------
           |      |
           |      O
           |     \\|/
           |      |
           |     / 
        """,
        """
           --------
           |      |
           |      O
           |     \\|/
           |      |
           |      
        """,
        """
           --------
           |      |
           |      O
           |     \\|
           |      |
           |     
        """,
        """
           --------
           |      |
           |      O
           |      |
           |      |
           |     
        """,
        """
           --------
           |      |
           |      O
           |    
           |      
           |     
        """,
        """
           --------
           |      |
           |      
           |    
           |      
           |     
        """
    ]
    return stages[incorrect_guesses]

# Function to display the current state of the word
def display_word(secret_word, guessed_letters):
    display = ""
    for letter in secret_word:
        if letter in guessed_letters:
            display += letter
        else:
            display += "_"
    return display

# Game loop
print("Welcome to Hangman!")

incorrect_guesses = 0
while True:
    # Display the hangman figure and the current state of the word
    print(display_hangman(incorrect_guesses))
    print(display_word(secret_word, guessed_letters))
    
    # Prompt the user for a guess
    guess = input("Guess a letter: ").lower()
    
    # Check if the guess is a single letter
    if len(guess) != 1:
        print("Please enter a single letter.")
        continue
    
    # Check if the letter has already been guessed
    if guess in guessed_letters:
        print("You have already guessed that letter.")
        continue
    
    # Add the guessed letter to the list
    guessed_letters.append(guess)
    
    # Check if the guess is correct
    if guess in secret_word:
        print("Correct guess!")
    else:
        print("Incorrect guess!")
        incorrect_guesses += 1
    
    # Check if the player has won or lost
    if display_word(secret_word, guessed_letters) == secret_word:
        print("Congratulations! You won!")
        break
    elif incorrect_guesses == max_attempts:
        print("You lost! The word was:", secret_word)
        break