import turtle
turtle.bgcolor("black")

squary = turtle.Turtle()
squary.speed(200)
squary.pencolor("sky blue")
for i in range(600):
    squary.forward(i)
    squary.left(91)
    