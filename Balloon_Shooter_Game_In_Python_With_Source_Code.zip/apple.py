import turtle
import random

# Set up the screen
screen = turtle.Screen()
screen.title("Apple Collecting Game")
screen.bgcolor("green")
screen.setup(width=600, height=600)
screen.tracer(0)

# Create the player turtle
player = turtle.Turtle()
player.shape("turtle")
player.color("black")
player.penup()

# Set the player speed
player_speed = 15

# Create the apple turtle
apple = turtle.Turtle()
apple.shape("circle")
apple.color("red")
apple.penup()
apple.goto(random.randint(-280, 280), random.randint(-280, 280))

# Set the score
score = 0

# Create the score turtle
score_turtle = turtle.Turtle()
score_turtle.hideturtle()
score_turtle.penup()
score_turtle.color("white")
score_turtle.goto(0, 260)
score_turtle.write("Score: {}".format(score), align="center", font=("Courier", 24, "bold"))

# Function to move the player turtle
def move_up():
    y = player.ycor()
    if y < 280:
        y += player_speed
    player.sety(y)

def move_down():
    y = player.ycor()
    if y > -280:
        y -= player_speed
    player.sety(y)

def move_left():
    x = player.xcor()
    if x > -280:
        x -= player_speed
    player.setx(x)

def move_right():
    x = player.xcor()
    if x < 280:
        x += player_speed
    player.setx(x)

# Keyboard bindings
screen.listen()
screen.onkeypress(move_up, "Up")
screen.onkeypress(move_down, "Down")
screen.onkeypress(move_left, "Left")
screen.onkeypress(move_right, "Right")

# Main game loop
while True:
    screen.update()

    # Check for collision between player and apple
    if player.distance(apple) < 20:
        apple.goto(random.randint(-280, 280), random.randint(-280, 280))
        score += 1
        score_turtle.clear()
        score_turtle.write("Score: {}".format(score), align="center", font=("Courier", 24, "bold"))

    # Check for game over condition
    if score == 10:
        score_turtle.goto(0, 0)
        score_turtle.write("You collected 10 apples!\nGame Over", align="center", font=("Courier", 24, "bold"))
        break
